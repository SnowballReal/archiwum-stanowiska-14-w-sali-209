let itterationCount; 
let LargestNumber;   
let ArraySum;        
let tablica = [];    
let tablicaDwa;      



function FindLargestNumber() {

  itterationCount = parseInt(prompt("Ilu Liczb tom podeć?"), 10);


  if (isNaN(itterationCount) || itterationCount <= 0) {
    alert("Prosze podej prowidłowom liczbe.");
    return;
  }

  tablica = []; 
  ArraySum = 0; 

  for (let i = 0; i < itterationCount; i++) {
    tablica.push(Math.floor(Math.random() * 1001)); 
  }

  tablicaDwa = [...tablica].sort((a, b) => b - a);

  LargestNumber = tablicaDwa[0];

  ArraySum = tablica.reduce((sum, num) => sum + num, 0);

  const uniqueNumbers = [... new Set(tablica)];

  document.getElementById("BiggestNumber").innerHTML = LargestNumber;
  document.getElementById("ArraySum").innerHTML = ArraySum;
  document.getElementById("arrayOne").innerHTML = tablica.join(", ");
  document.getElementById("arrayTwo").innerHTML = tablica.reverse().join(", ");
  document.getElementById("arrayThree").innerHTML = uniqueNumbers.join(", ");
}



/*console.log("balls");

let name = "cwel";
console.log(name)

var name2 = 'pedał';

let nameOfTheKingOfTheLustLayerOfHell = 'King Minos';

const nineeleven = '9.11.2001';

if (nameOfTheKingOfTheLustLayerOfHell === 'King Minos') {
    console.log("JUDGEMENT!!!")
}

for(let i = 0; i < 10; i ++){
    console.log(i);
}

let iterrator = 0
while(iterrator < 5){
    console.log(iterrator)
    iterrator++;
}

let coolvar = 1;

while(coolvar == 1){
let tries = 1;

console.log(tries)

let random1 = Math.floor(Math.random() * (10 - 1) + 1);
console.log("liczbą jest: ", random1)

let random2 = Math.floor(Math.random() * (10 - 1) + 1);
console.log(" komputer zdgadł: ", random2)

let guess = prompt('guess the number to access the website : ')

if (random1 == random2){
    console.warn("komputer wygrał :3")
}else if(random1 != random2) {
    console.warn("komputer przegrał >:3")
}

if (random1 == guess){
    console.warn("wygrałeś :3")
    coolvar = 0;
}else if (random1 != guess){
    console.warn("przegrałęś >:3")
}

tries ++

}*/

/*let date = new Date();

let Day

switch(date.getDay()) {
    case 0:
        Day = "SunDay";
      break;
    case 1:
        Day = "monDay";
      break;
    case 2:
        Day = "tuesDay";
      break;
    case 3:
        Day = "wednesDay";
      break;
    case 4:
        Day = "thursDay";
      break;
    case 5:
        Day = "FriDay";
      break;
    case 6:
        Day = "SaturDay";
      break;
  }


  console.log(Day);

  let num = 7;
                    
  let sum = num;

  for (let i = 1; i < num; i++) {
      sum = sum * i;
  }

  console.log(sum);

  function potega() {
    let newnum = 3;

    let potega = prompt("podej potęgę");

    while (potega > 1) {
        newnum = newnum * newnum;
        potega--;
    }
    console.log(newnum);
}
potega();

function print(x) {
	console.log(x);
}

print('Elo 2');

function Calculator(a, b, sign) {
	
	switch(sign){
		case 0 :
			console.log(a + b);
		case 1 :
			console.log(a - b);
		case 2:
			console.log(a * b);
		case 3:
			console.log(a / b);
	}
}

Calculator(prompt('podej pierwszą liczbę'), prompt('podej drugą liczbę'), prompt('jaki wzór wariacie? (0 = +; 1 = -; 2 = *; 3 = /; )'));*/