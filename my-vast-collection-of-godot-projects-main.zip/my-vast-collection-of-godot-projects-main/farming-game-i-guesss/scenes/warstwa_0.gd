extends TileMapLayer
@onready var character: CharacterBody2D = $"../CharacterBody2D"


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	var coolvar = get_cell_source_id(Vector2(1,1))
	set_cell(Vector2(character.position / 82), 0, Vector2(1,0))
	print(coolvar)
	pass
