extends CharacterBody2D
var moveSpeed = 10;
@onready var sprite: Sprite2D = $Sprite2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

func move(x,y):
	move_and_collide(Vector2(x,y))

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	if Input.is_action_just_pressed("mouse") :
		print("piwo")
	if Input.is_action_pressed("move_left"):
		sprite.flip_h=true
		move(moveSpeed * -1,0)
	if Input.is_action_pressed("move_right"):
		sprite.flip_h = false
		move(moveSpeed,0)
	if Input.is_action_pressed("move_up"):
		move(0,moveSpeed *-1)
	if Input.is_action_pressed("move_down"):
		move(0,moveSpeed)
	if Input.is_action_pressed("move_left") and Input.is_action_pressed("move_up") or Input.is_action_pressed("move_right") and Input.is_action_pressed("move_up") or Input.is_action_pressed("move_right") and Input.is_action_pressed("move_down") or Input.is_action_pressed("move_left") and Input.is_action_pressed("move_down"):
		moveSpeed = 10 / 1.41
	else:
		moveSpeed = 10
	pass
