extends  Area2D
@onready var collision: CollisionShape2D = $CollisionShape2D
@onready var scene: Sprite2D = $".."
@onready var animationPlayer: AnimationPlayer = $"../AnimationPlayer"

var mouseOnGun = false
var previousMousePos = Vector2(0,0)
var presentMousePos = Vector2(0,0)
var gunPosChange = 0
var timeBetweenFrames = 0.0
var seconds = 0
var sceneMove = 0

func _ready() -> void:
	pass

func moveAway():
	animationPlayer.play("move_away")



func _process(delta: float) -> void:
	previousMousePos = presentMousePos
	var mousePos = get_global_mouse_position()
	presentMousePos = mousePos
	var mousePosChange = presentMousePos -previousMousePos
	
	timeBetweenFrames += delta
	
	if timeBetweenFrames > 1:
		timeBetweenFrames = 0
		seconds = seconds + 1
		print(seconds)
	
	
	if Input.is_action_pressed("mouse") and mouseOnGun == true:
		position.y = position.y + (mousePosChange.y / 1.5)
		gunPosChange = gunPosChange + mousePosChange.y / 1.5
		if gunPosChange < -120:
			moveAway()
	


func _on_mouse_entered() -> void:
	mouseOnGun = true


func _on_mouse_exited() -> void:
	mouseOnGun = false
