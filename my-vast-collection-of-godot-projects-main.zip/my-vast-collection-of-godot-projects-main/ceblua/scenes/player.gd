extends RigidBody2D
var screensize
@onready var raycast: RayCast2D = $RayCast2D
var coolgravity = 0
var jumping = false
@onready var sprite: Sprite2D = $Sprite2D
@onready var collison: CollisionShape2D = $CollisionShape2D
@onready var rigidbody: RigidBody2D = $"."
var brick = load("res://scenes/throwable_brick.tscn")
var badguy = load("res://scenes/bad guy.tscn")
var coolvar = -1
signal hit

func start(pos):
	position = pos
	show()
	$CollisionShape2D.disabled = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	screensize = get_viewport_rect().size
	start(Vector2(-243.0, -237.0))
	pass # Replace with function body.

func move(speed, direction):
	move_and_collide(Vector2(speed*direction, 0.0))
	if direction == 1:
		sprite.flip_h = false
	elif direction == -1 :
		sprite.flip_h = true

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	if jumping == true:
		move_and_collide(Vector2(0.0, -1*coolgravity))
		if coolgravity < -20:
			pass
		else:
			coolgravity-=1
		
		if coolgravity == 0 :
			jumping = false  
	elif raycast.is_colliding() :
		coolgravity = 0
	elif jumping == false:
		coolgravity+= 1
		move_and_collide(Vector2(0.0, coolgravity))
	
	if Input.is_action_pressed("move_right"):
		move(10.0, 1)
	elif Input.is_action_pressed("move_left"):
		move(10.0, -1)
	
	if Input.is_action_pressed("jump") and raycast.is_colliding() :
		if jumping == false:
			jumping = true
			coolgravity = 20
		elif jumping == true:
			pass    
	
	if Input.is_action_just_pressed("throw_brick"):
		print("brick thrown")
	
	pass


func _on_body_entered(body: Node2D) -> void:
	hide()
	hit.emit()
	$CollisionShape2D.set_deferred("disabled", true)
	pass # Replace with function body.
