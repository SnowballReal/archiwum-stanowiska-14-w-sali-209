extends Node2D
@onready var sprite:Sprite2D = $Sprite2D
@onready var laser:Line2D = $Sprite2D/laser
@onready var bullerTrail:Line2D = $Sprite2D/Line2D
var coolvar = 139.0;

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	pass # Replace with function body.
	

func wait(seconds: float) -> void:
	await get_tree().create_timer(seconds).timeout

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if bullerTrail.get_point_position(1):
		bullerTrail.remove_point(1)
		coolvar = 139
	look_at(get_global_mouse_position())
	sprite.look_at(get_global_mouse_position())
	if global_rotation * 60 > 90 or global_rotation * 60 < -90:
		sprite.flip_v = true
		bullerTrail.get_point_position(0).y = 38
		laser.position.y = 38
		bullerTrail.position.y = 36
		sprite.position.y = -36
	else:
		sprite.flip_v = false
		laser.position.y = 0
		bullerTrail.position.y = 0
		sprite.position.y = 0
	
	if Input.is_action_pressed("throw_brick"):
		bullerTrail.add_point(Vector2(coolvar, 0), 1)
		for i in 20:
			coolvar += 40
			bullerTrail.set_point_position(1, Vector2(coolvar, 0))
		coolvar = 139
	pass
