extends RigidBody2D
@onready var collision : CollisionShape2D = $CollisionShape2D
@onready var damage : CollisionShape2D = $damageColision
@onready var sprite : Sprite2D = $Sprite2D
@onready var raycastX : RayCast2D = $raycastX
@onready var raycastY : RayCast2D = $raycastY

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
